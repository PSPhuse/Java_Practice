package com.C_Dac.ac;

public class AC {
	private int count = 97;
	
	public int getotal()
	{
		return  count;
	}

}
