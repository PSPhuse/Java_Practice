package com.C_Dac.bda;

public class BDA {
	private int count=56;
	
	public int getTotal()
	{
		return count;
	}
}
