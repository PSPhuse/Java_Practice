package com.C_Dac.ai;

public class AI {

	private int count=37;
	
	public int getTotal()
	{
		return count;
	}
}
