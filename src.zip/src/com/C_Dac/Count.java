package com.C_Dac;
import com.C_Dac.ac.*;
import com.C_Dac.ai.*;
import com.C_Dac.bda.BDA;

public class Count {

	public static void main(String[] args) {

		AC a = new AC();
		BDA b = new BDA();
		AI c = new AI();
		
		System.out.println("Total Number of Student:"+(a.getotal()+b.getTotal()+c.getTotal()));
		
		
	}

} 
