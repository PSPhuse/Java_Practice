package com.company.accounts;

public class Account {
	private long accNo;
	private String bankName;
	
	public Account(long accNo,String bankName)
	{
		this.accNo=accNo;
		this.bankName=bankName;
	}
	public void displayAccountDetails()
	{
		System.out.println("Account Number:"+accNo);
		System.out.println("Bank Name:"+bankName);
	}
	

}
