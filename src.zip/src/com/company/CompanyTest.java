package com.company;
import com.company.accounts.*;      //implicit import
import com.company.hr.Employee;     //Explicit import

public class CompanyTest {

	public static void main(String[] args) {
		Employee e = new Employee("Ganesh",123);
		e.employeeDetail();
		
		Account a= new Account(47856,"SBI");
		a.displayAccountDetails();
	}

}
