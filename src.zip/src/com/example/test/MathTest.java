package com.example.test;

import com.example.math.Calculator;

public class MathTest {

	public static void main(String[] args) {

		
		Calculator c=new Calculator();
		System.out.println("Addition:"+c.addition(20, 55));
		System.out.println("Substraction:"+c.subtract(20, 5));
	}

}
