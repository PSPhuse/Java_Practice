package com.example.utils;

public class MathUnits {

	public static double PI()
	{
		return Math.PI;
	}
	
}
