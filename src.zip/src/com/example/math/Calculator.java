package com.example.math;

public class Calculator {
	
	public int addition(int num1,int num2)
	{
		return(num1+num2);
	}
	
	public int subtract(int num1,int num2)
	{
		return (num1-num2);
	}
}
