package com.example.shapes;

public class ShapeTest {

	public static void main(String[] args) {
		
		Circle c=new Circle();
		c.area(5);
	}
}
