package com.example.shapes;
import com.example.utils.*;

class Circle {
	
	public void area(int r)
	{
		System.out.println( "Area of Circle:"+MathUnits.PI()*r*r);
		
	}
}
